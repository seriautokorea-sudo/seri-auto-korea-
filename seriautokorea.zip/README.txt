Seri Auto Korea - paketë ZIP
Përmban një faqe HTML (index.html) të përmirësuar duke korrigjuar formularin 'mailto' dhe disa përmirësime të dizajnit bazë.
Për ta përdorur: nxirrni skedarin dhe hapni index.html në shfletuesin tuaj.
Nëse dëshironi, mund të shtojmë gjithashtu një skedar CSS, imazhe të modeleve ose një back-end për dërgesë reale të email-ve.
